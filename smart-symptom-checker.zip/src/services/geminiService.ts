import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeSymptoms(symptoms: string, language: string, age: number) {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are an AI medical assistant for the "Smart Symptom Checker" app.
    Analyze the symptoms provided by a user of age ${age}.
    
    CRITICAL RULES:
    1. NEVER provide a confirmed diagnosis.
    2. ALWAYS include the disclaimer: "This is not a medical diagnosis. Please consult a doctor."
    3. Classify the condition into 3 severity levels: "Mild", "Moderate", or "Emergency".
    4. Severity Logic:
       - Emergency: Life-threatening (e.g., chest pain, difficulty breathing, severe bleeding, stroke symptoms). 
         DO NOT provide remedies. Provide ONLY an emergency alert and suggest immediate ER.
       - Moderate: Concerning but not immediately fatal (e.g., high fever, persistent pain).
         Provide precautions and suggest visiting a doctor soon.
       - Mild: Common issues (e.g., common cold, small scrapes).
         Provide home remedies and prevention tips.
    5. Output must be in ${language}.
    6. Return the response in strict JSON format.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: symptoms,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        required: ["severity", "summary", "actions", "conditions", "disclaimer"],
        properties: {
          severity: {
            type: Type.STRING,
            enum: ["Mild", "Moderate", "Emergency"],
            description: "The severity classification."
          },
          summary: {
            type: Type.STRING,
            description: "A brief summary of the symptoms analysis."
          },
          actions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Remedies (for Mild) or Precautions (for Moderate) or emergency steps (for Emergency)."
          },
          conditions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Possible common conditions (MOCK/EDUCATIONAL ONLY). Leave empty for Emergency."
          },
          disclaimer: {
            type: Type.STRING,
            description: "The mandatory medical disclaimer."
          }
        }
      }
    }
  });

  return JSON.parse(response.text);
}
